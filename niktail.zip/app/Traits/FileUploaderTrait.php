<?php

namespace App\Traits;

trait FileUploaderTrait
{
    public $file_url='files/';



}