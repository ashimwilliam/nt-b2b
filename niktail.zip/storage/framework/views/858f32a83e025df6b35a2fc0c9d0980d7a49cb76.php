<?php $__env->startSection('content'); ?>
    <div class="animate form login_form">
        <section class="login_content">
            <form method="POST" action="<?php echo e(route('admin-login')); ?>">
                <?php echo csrf_field(); ?>
                <h1>Admin Login</h1>
                <div>
                    <input <?php if($errors->has('email')): ?> style="margin-bottom: 10px !important;" <?php endif; ?> id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                    <?php if($errors->has('email')): ?>
                        <p style="text-align: left !important; color: red; margin-bottom: 10px !important;">
                            <?php echo e($errors->first('email')); ?>

                        </p>
                    <?php endif; ?>
                </div>
                <div>
                    <input <?php if($errors->has('email')): ?> style="margin-bottom: 10px !important;" <?php endif; ?> id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                    <?php if($errors->has('password')): ?>
                        <p style="text-align: left !important; color: red;">
                            <?php echo e($errors->first('password')); ?>

                        </p>
                    <?php endif; ?>
                </div>
                <div>
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(__('Login')); ?>

                    </button>
                    
                </div>

                <div class="clearfix"></div>

                <div class="separator">
                    

                    <div class="clearfix"></div>
                    <br />

                    <div>
                        <h1><i class="fa fa-paw"></i> Gentelella Alela!</h1>
                        <p>©2016 All Rights Reserved. Gentelella Alela! is a Bootstrap 3 template. Privacy and Terms</p>
                    </div>
                </div>
            </form>
        </section>
    </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ashim/workspace/niktail/resources/views/auth/adminLogin.blade.php ENDPATH**/ ?>