<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">
        <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>List Product</h3>
                </div>
                <div class="pull-right">
                    <a href="<?php echo e(URL::to('admin/product/create')); ?>">
                        <button type="button" class="btn btn-success">Create New Record</button>
                    </a>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_content">

                            <div class="table-responsive">
                                <table class="table table-striped jambo_table bulk_action">
                                    <thead>
                                    <tr class="headings">
                                        <th class="column-title">Name</th>
                                        <th class="column-title">SKU</th>
                                        <th class="column-title">Image</th>
                                        <th class="column-title">HSN Code</th>
                                        <th class="column-title">Category</th>
                                        <th class="column-title">Sub Category</th>
                                        <th class="column-title">Brand</th>
                                        <th class="column-title">Status </th>
                                        <th class="column-title no-link last"><span class="nobr">Action</span>
                                        </th>
                                    </tr>
                                    </thead>

                                    <tbody>
                                    <?php if($records && count($records) > 0): ?>
                                        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="even pointer">
                                            <td class=" "><?php echo e($item->sku_name); ?></td>
                                            <td class=" "><?php echo e($item->sku_number); ?></td>
                                            <td class=" ">
                                                <?php if($item->image_1 != 0): ?>
                                                    <img src="<?php echo e(asset('uploads/product/'.$item->image_1)); ?>" width="50" style="" />
                                                <?php endif; ?>
                                            </td>
                                            <td class=" "><?php echo e($item->hsncode->hsncode); ?></td>
                                            <td class=" "><?php echo e($item->category->title); ?></td>
                                            <td class=" "><?php echo e($item->subcategory->title); ?></td>
                                            <td class=" "><?php echo e($item->brand->title); ?></td>
                                            <td class="a-right a-right ">
                                                <?php if($item->status == 1): ?>
                                                    <span class="label label-success">Active</span>
                                                <?php else: ?>
                                                    <span class="label label-danger">In-Active</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class=" last"><a href="<?php echo e(URL::to('admin/product/'.$item->id).'/edit'); ?>">Edit</a></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr class="even pointer">
                                            <td colspan="9">No record found.</td>
                                        </tr>
                                    <?php endif; ?>
                                    </tbody>
                                </table>
                                <?php echo e($records->links()); ?>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ashim/workspace/niktail/resources/views/admin/product/index.blade.php ENDPATH**/ ?>