<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">
        <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>List Main Sub-Category</h3>
                </div>
                <div class="pull-right">
                    <a href="<?php echo e(URL::to('admin/subcategory/create')); ?>">
                        <button type="button" class="btn btn-success">Create New Sub-Category</button>
                    </a>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_content">

                            <div class="table-responsive">
                                <table class="table table-striped jambo_table bulk_action">
                                    <thead>
                                    <tr class="headings">
                                        <th class="column-title">Sub Category</th>
                                        <th class="column-title">Category</th>
                                        <th class="column-title">Description</th>
                                        <th class="column-title">Slug</th>
                                        <th class="column-title">Status </th>
                                        <th class="column-title no-link last"><span class="nobr">Action</span>
                                        </th>
                                    </tr>
                                    </thead>

                                    <tbody>
                                    <?php if($records && count($records) > 0): ?>
                                        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="even pointer">
                                            <td class=" "><?php echo e($item->title); ?></td>
                                            <td class=" "><?php echo e((isset($item->category) ? $item->category->title : "")); ?></td>
                                            <td class=" "><?php echo e($item->description); ?></td>
                                            <td class=" "><?php echo e($item->slug); ?></td>
                                            <td class="a-right a-right ">
                                                <?php if($item->status == 1): ?>
                                                    <span class="label label-success">Active</span>
                                                <?php else: ?>
                                                    <span class="label label-danger">In-Active</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class=" last"><a href="<?php echo e(URL::to('admin/subcategory/'.$item->id).'/edit'); ?>">Edit</a></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr class="even pointer">
                                            <td colspan="6">No record found.</td>
                                        </tr>
                                    <?php endif; ?>
                                    </tbody>
                                </table>
                                <?php echo e($records->links()); ?>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ashim/workspace/niktail/resources/views/admin/subcategory/index.blade.php ENDPATH**/ ?>