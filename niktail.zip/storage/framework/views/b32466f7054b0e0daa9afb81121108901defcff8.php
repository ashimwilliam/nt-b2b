<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">
        <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>List Retailer</h3>
                </div>
                <div class="pull-right">
                    <a href="">
                        <button type="button" class="btn btn-success">Create New Retailer</button>
                    </a>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_content">

                            <div class="table-responsive">
                                <table class="table table-striped jambo_table bulk_action">
                                    <thead>
                                    <tr class="headings">
                                        <th class="column-title">Name</th>
                                        <th class="column-title">Email</th>
                                        
                                        <th class="column-title no-link last"><span class="nobr">Action</span>
                                        </th>
                                    </tr>
                                    </thead>

                                    <tbody>
                                    <?php if($records && count($records) > 0): ?>
                                        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="even pointer">
                                            <td class=" "><?php echo e($item->name); ?></td>
                                            <td class=" "><?php echo e($item->email); ?></td>
                                            
                                            <td class=" last"><a href="#">Edit</a></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr class="even pointer">
                                            <td colspan="5">No record found.</td>
                                        </tr>
                                    <?php endif; ?>
                                    </tbody>
                                </table>
                                <?php echo e($records->links()); ?>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ashim/workspace/niktail/resources/views/admin/user/index.blade.php ENDPATH**/ ?>